import React, { Component } from "react";

function Hero() {
  return (
    <div className="row">
      <div className="jumbotron col-10 offset-1">
        <h1>AuthorQuiz</h1>
        <p>Select the Book written by the author shown</p>
      </div>
    </div>
  );
}

function Turn(author, books, turnData) {
  return (
    <div className="row turn" style={{ backgroundColor: "white" }}>
      <div className="col-4 offset-1">
        <img src={author.imageUrl} className="authorimage" alt="Author"></img>
      </div>
      <div className="col-6">
        {books.map(title => (
          <p>{title}</p>
        ))}
      </div>
    </div>
  );
}

function Continue() {
  return <div></div>;
}

function Footer() {
  return (
    <div id="footer" className="row">
      <div className="col-12">
        <p className="text-muted credit">
          All images are from{" "}
          <a href="https://commons.wikimedia.org/wiki/Mai">wikimedia Commons</a>
        </p>
      </div>
    </div>
  );
}

function AuthorQuiz(turnData) {
  return (
    <div className="container-fluid">

      <Hero />
      <Turn {...turnData} />
      <Continue />
      <Footer />

    </div>
  );
}

export default AuthorQuiz;
