import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
import registerServiceWorker from "./registerServiceWorker";
import AuthorQuiz from "./AuthorQuiz";
import Form from "./Form";

const authors = [
  {
    name: "Harsha",
    imageUrl: "images/authors/charlesdickens",
    imageSource: "Wikimedia Commons",
    books: ["The Adventure"]
  }
];

const state = {
  turnData: {
    author: author[0],
    books: author[0].books
  }
};

ReactDOM.render(<AuthorQuiz {...state} />, document.getElementById("root"));
registerServiceWorker();
