import React, { Component } from "react";
import logo from "./logo.svg";
import "./App.css";
import "./style.css";
import AuthorQuiz from "./AuthorQuiz";
import "./bootstrap.min.css";

class App extends Component {
  render() {
    return (
      <div className="App">
        <AuthorQuiz />
      </div>
    );
  }
}

export default App;
