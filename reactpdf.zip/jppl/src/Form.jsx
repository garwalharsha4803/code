import React, { Component } from "react";

class Form extends Component {
  state = {
    firstname: "",
    middlename: "",
    lastname: ""
  };

  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      firstname: this.state.firstname,
      middlename: this.state.middlename,
      lastname: this.state.lastname
    });
  };

  handleChange = e => {
    const target = e.target;
    const name = target.name;
    const value = target.value;

    this.setState({
      [name]: value
    });

    //console.log(this.state.middlename);
  };

  render() {
    return (
      <div className="container">
        <form onSubmit={this.handleSubmit}>
          <br />
          <br />
          <input
            type="text"
            name="firstname"
            value={this.state.firstname}
            onChange={this.handleChange}
          ></input>
          <br />
          <br />
          <input
            type="text"
            name="middlename"
            value={this.state.middlename}
            onChange={this.handleChange}
          ></input>
          <br />
          <br />
          <input
            type="text"
            name="lastname"
            value={this.state.lastname}
            onChange={this.handleChange}
          ></input>
          <br />
          <br />

          <button type="submit">Submit</button>
        </form>
        <div className="show">{this.state.firstname}</div>
      </div>
    );
  }
}

export default Form;
