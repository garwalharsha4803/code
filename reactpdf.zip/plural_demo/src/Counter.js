import React, { Component, useState } from "react";

function Button(props) {
  const handleClick = () => props.onClickFunction(props.increment);
  return (
    <div>
      <button onClick={handleClick}>+ {props.increment}</button>
    </div>
  );
}

function Display(props) {
  return <div>{props.message}</div>;
}

function Counter() {
  const [clickcounter, setcounter] = useState(5);
  const incrementCounter = incrementValue =>
    setcounter(clickcounter + incrementValue);
  return (
    <>
      <Button onClickFunction={incrementCounter} increment={1} />
      <Button onClickFunction={incrementCounter} increment={5} />
      <Button onClickFunction={incrementCounter} increment={10} />
      <Button onClickFunction={incrementCounter} increment={100} />
      <Display message={clickcounter} />
    </>
  );
}

export default Counter;
