import React, { Component, useState } from "react";

function CountButton(props) {
  const handleClick = () => props.incrementFunction(props.increment);
  return (
    <div>
      <button onClick={handleClick}>+{props.increment}</button>
    </div>
  );
}

function Show(props) {
  return <div>{props.show}</div>;
}

function Counterdemo() {
  const [counter, setcounter] = useState(5);
  const increcounter = incrementvalue => setcounter(counter + incrementvalue);
  return (
    <>
      <CountButton incrementFunction={increcounter} increment={1} />
      <CountButton incrementFunction={increcounter} increment={10} />
      <CountButton incrementFunction={increcounter} increment={100} />
      <CountButton incrementFunction={increcounter} increment={1000} />
      <Show show={counter} />
    </>
  );
}

export default Counterdemo;
