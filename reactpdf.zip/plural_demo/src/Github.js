import React, { Component } from "react";
import "./style.scss";
import axios from "axios";

// const testData = [
//   {
//     name: "Dan Abramov",
//     avatar_url: "https://avatars0.githubusercontent.com/u/810438?v=4",
//     company: "@facebook"
//   },
//   {
//     name: "Sophie Alpert",
//     avatar_url: "https://avatars2.githubusercontent.com/u/6820?v=4",
//     company: "Humu"
//   },
//   {
//     name: "Sebastian Markbåge",
//     avatar_url: "https://avatars2.githubusercontent.com/u/63648?v=4",
//     company: "Facebook"
//   }
// ];

function CardList(props) {
  return (
    <div>
      {props.profile.map(profile => (
        <Card key={profile.id} {...profile} />
      ))}
    </div>
  );
}

class Card extends Component {
  render() {
    const profile = this.props;
    return (
      <div>
        <div className="github-profile">
          <img src={profile.avatar_url} />
          <div className="info">
            <div className="name">{profile.name}</div>
            <div className="company">{profile.company}</div>
          </div>
        </div>
      </div>
    );
  }
}

class Form extends Component {
  state = {
    username: ""
  };

  // userNameInput = React.createRef();

  handleSubmit = async event => {
    event.preventDefault();
    const resp = await axios.get(
      `https://api.github.com/users/${this.state.username}`
    );
    // console.log(resp.data);

    this.props.onsubmit(resp.data);
    this.setState({ username: "" });
  };

  render() {
    return (
      <div>
        <form onSubmit={this.handleSubmit}>
          <input
            type="text"
            placeholder="Enter username"
            //ref={this.userNameInput}
            value={this.state.username}
            onChange={event => this.setState({ username: event.target.value })}
          ></input>
          <button>Add</button>
        </form>
      </div>
    );
  }
}

class HeaderGit extends Component {
  state = {
    profiles: []
  };

  addNewProfile = profileData => {
    // console.log("App", profileData);
    this.setState(prevState => ({
      profiles: [...prevState.profiles, profileData]
    }));
  };
  render() {
    return (
      <div>
        <div className="header">{this.props.title}</div>
        <Form onsubmit={this.addNewProfile} />
        <CardList profile={this.state.profiles} />
      </div>
    );
  }
}

class Github extends Component {
  render() {
    return (
      <div>
        <HeaderGit title="The Github Cards App" />
      </div>
    );
  }
}

export default Github;
