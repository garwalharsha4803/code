import React, { Component } from "react";
import logo from "./logo.svg";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { Button } from "reactstrap";

function Hero() {
  return <div>Hero</div>;
}

function Turn() {
  return <div>Turn</div>;
}

function Continue() {
  return <div>Continue</div>;
}

class AuthorQuiz extends Component {
  render() {
    return (
      <div className="container-fluid">
        <Hero />
        <Turn />
        <Continue />
      </div>
    );
  }
}

export default AuthorQuiz;
