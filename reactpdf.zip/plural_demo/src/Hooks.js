import React, { Component, useState, useEffect } from "react";

const HookLifecycle = () => {
  const [counter, setcounter] = useState(0);
  const [name, setname] = useState("Harsha");
  return (
    <div>
      <p>
        Hi {name} has clicked {counter} times.
      </p>
      <button onClick={() => setcounter(counter + 1)}> Click</button>
      <button onClick={() => setname(name === "Harsha" ? "Verma" : "Harsha")}>
        Change name
      </button>
    </div>
  );
};

export default HookLifecycle;
