import { createStore } from "redux";
import reducer from "./reducers/reducer";

const store = createStore(reducer);

const store2 = createStore(reducer, [preloadedState], [enhancer]);

// create store function has three arguments
// reducer is a function that returns the next state.
// Preloaded is an optional argument and is the initial state of the app
// enhancer is also optional and will enhance store with third party capabilities.

// A store has three important methods:

store.getState();

// Retrieves the current state

store.dispatch({ type: "ITEMS_REQUEST" });

// it allows to dispatch an application to change the state

store.subscribe(() => {
  console.log(store.getState());
});

// It registers a callback that store will call when an action has been dispatched.
// As soon as the redux updates the state, view ill re-render automatically.

// subscribe function will also return unsubscribe function

const unsubscribe = store.subscribe(() => {
  console.log(store.getState());
});

unsubscribe();
