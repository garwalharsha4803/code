import React, { Component } from "react";

class LeftSidebar extends Component {
  render() {
    const greeting1 = "Hi Greeting first";
    const greeting = "props using diff component";

    return (
      <div className="content">
        {this.props.title}
        <p>{greeting1}</p>
        <Greetings greeting={greeting} />
      </div>
    );
  }
}

class Greetings extends Component {
  state = {};
  render() {
    const greeting3 = "using props inside same component";
    const greeting4 = "props recieved in the function as arguments";
    return (
      <p>
        {greeting3}
        <h4>
          <br />
          {this.props.greeting}
        </h4>
      </p>
    );
  }
}

const greet4 = props => <p> {props.greeting4}</p>;

export default LeftSidebar;
