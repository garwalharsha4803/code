import React, { Component } from "react";

class Home extends Component {
  _getComments() {
    const commentList = [
      { id: 1, author: "Brayns", body: "First comment" },
      { id: 2, author: "Chetan", body: "Second comment" },
      { id: 3, author: "Mangesh", body: "Third comment" }
    ];
    return commentList.map(comment => {
      return (
        <Comments
          author={comment.author}
          body={comment.body}
          key={comment.id}
        />
      );
    });
  }
  render() {
    const comments = this._getComments();
    const now = new Date();

    const topicsList = ["A", "B", "c"];

    return (
      <div>
        Home page !!!!
        <p>Current Time: {now.toTimeString()}</p>
        <ul>
          {topicsList.map(topic => (
            <li>{topic}</li>
          ))}
        </ul>
        <hr />
        <div className="comment-Box">
          <h3>Comments</h3>
          <h4 className="comment-count">2 Comments</h4>
          <div className="comment-list">{comments}</div>
        </div>
      </div>
    );
  }
}

class Comments extends Component {
  render() {
    return (
      <div>
        <div className="comment">
          <p className="comment-header">{this.props.author}</p>
          <p className="comment-body">{this.props.body}</p>
          <div className="comment-footer">
            <a href="#" className="comment-footer-delete">
              Delete Comment
            </a>
          </div>
        </div>
        <hr />
      </div>
    );
  }
}

export default Home;
