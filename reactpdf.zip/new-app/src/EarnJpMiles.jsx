import React, { Component } from "react";

class EarnJpMiles extends Component {
  render() {
    return <div>Welcome to Earn JP Miles page !!!!</div>;
  }
}
export default EarnJpMiles;
