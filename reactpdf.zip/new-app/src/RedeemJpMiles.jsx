import React, { Component } from "react";

class RedeemJpMiles extends Component {
  render() {
    const now = new Date();
    const countryList = ["India", "Australia", "NewZealand"];

    return (
      <div>
        Welcome to RedeemJpMiles page !!!!
        <p>{now.toTimeString()}</p>
        <ol>
          Country List Below:
          {countryList.map(country => (
            <li>{country}</li>
          ))}
        </ol>
        <hr />
        <div className="comment-section">
          <CommentBox1 />
        </div>
      </div>
    );
  }
}

class CommentBox1 extends Component {
  constructor() {
    super();
    this.state = {
      showComments: true,
      comments: []
    };
  }
  _getComList() {
    return this.state.comments.map(comment => {
      return (
        <Comment1
          author={comment.author}
          body={comment.body}
          key={comment.id}
        />
      );
    });
  }

  _getComTitle(commentCount) {
    if (commentCount === 0) {
      return "No Comments";
    } else if (commentCount === 1) {
      return "1 Comment";
    } else {
      return commentCount + " " + "comments";
    }
  }
  _handleClick = () => {
    this.setState({
      showComments: !this.state.showComments
    });
  };

  render() {
    const commentAll = this._getComList();
    let buttonText = "show Comments";
    if (this.state.showComments) {
      buttonText = "Hide Comments";
    }

    return (
      <div>
        <h1>Comment Box</h1>
        <ComentForm addComment={this._addComment.bind(this)} />

        <h3>{this._getComTitle(commentAll.length)}</h3>
        <div className="comment-box">
          {this.state.showComments ? (
            <div className="all_comment">{commentAll} </div>
          ) : null}
          <button onClick={this._handleClick}>{buttonText}</button>
        </div>
      </div>
    );
  }
  _addComment(author, body) {
    const comment = {
      id: this.state.comments.length + 1,
      author,
      body
    };
    this.setState({ comments: this.state.comments.concat([comment]) });
  }
}

class ComentForm extends Component {
  render() {
    return (
      <form className="comment-form" onSubmit={this._handleSubmit.bind(this)}>
        <label>Join the discussion</label>
        <div className="comment-form-field">
          <input
            type="text"
            placeholder="Name"
            ref={input => (this._author = input)}
          />
          <textarea
            placeholder="comment"
            ref={textarea => (this._body = textarea)}
          />
        </div>
        <div className="comment-form-actions">
          <button type="submit">Post Comments</button>
        </div>
      </form>
    );
  }
  _handleSubmit(event) {
    event.preventDefault();
    let author = this._author;
    let body = this._body;

    this.props.addComment(author.value, body.value);
  }
}

class Comment1 extends Component {
  render() {
    return (
      <div>
        <div className="com-id">{this.props.id}</div>
        <div className="com-header">{this.props.author}</div>
        <div className="com-description">{this.props.body}</div>
        <hr />
      </div>
    );
  }
}

export default RedeemJpMiles;
