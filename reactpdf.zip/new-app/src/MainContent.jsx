import React, { Component } from "react";
import LeftSidebar from "./LeftSidebar";
import RightSidebar from "./RightSidebar";

class MainComponent extends Component {
  state = {};
  render() {
    return (
      <div className="main_content">
        <div className="container">
          <div className="row">
            <div className="col-lg-3">
              <LeftSidebar title="Harsha" />
            </div>
            <div className="col-lg-9">
              <RightSidebar title="Hey there !!" />
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default MainComponent;
