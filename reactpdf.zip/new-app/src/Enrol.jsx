import React, { Component } from "react";

class Enrol extends Component {
  constructor(props) {
    super(props);
    this.state = { name: "", email: "", comment: "", issubmit: false };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    this.setState({ [event.target.name]: event.target.value });
  }

  handleSubmit(event) {
    event.preventDefault();
    this.setState({ issubmit: true });
  }

  render() {
    let issubmit = "";
    if (this.state.issubmit) {
      issubmit = this.state.name + this.state.email + this.state.comment;
    }

    return (
      <div>
        <div className="enrol_leftside">
          Enrol Form
          <form onSubmit={this.handleSubmit}>
            <label>Name:</label>
            <input
              type="text"
              name="name"
              value={this.state.value}
              onChange={this.handleChange}
            />
            <br />
            <label>Email:</label>
            <input
              type="text"
              name="email"
              value={this.state.email}
              onChange={this.handleChange}
            />
            <br />
            <label>Comment:</label>
            <input
              type="text"
              name="comment"
              value={this.state.comment}
              onChange={this.handleChange}
            />
            <br />

            <input type="submit" value="submit" />
          </form>
        </div>
        <div className="enrol_rightside">{issubmit}</div>
      </div>
    );
  }
}

export default Enrol;
