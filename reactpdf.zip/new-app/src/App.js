import React, { Component } from "react";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Header from "./header";
import Content from "./Content";
import MainContent from "./MainContent";
import Footer from "./Footer";
import { Route, NavLink, BrowserRouter } from "react-router-dom";

<link
  href="https://fonts.googleapis.com/css?family=Montserrat:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i"
  rel="stylesheet"
/>;

class App extends Component {
  render() {
    return (
      <BrowserRouter>
        <div>
          <Header />
          <MainContent />
          <Footer />
        </div>
      </BrowserRouter>
    );
  }
}

export default App;
