import React, { Component } from "react";

class Demo extends Component {
  state = {};
  render() {
    return <div>Hii</div>;
  }
}

export default Demo;
