import React, { Component } from "react";
import { Route } from "react-router-dom";

import Home from "./Home";
import Form from "./Form";
import RedeemJpMiles from "./RedeemJpMiles";
import OffersDeals from "./OffersDeals";
import AboutUs from "./AboutUs";
import Enrol from "./Enrol";

class Content extends Component {
  state = {
    fields: {}
  };
  onSubmit = fields => {
    this.setState({ fields });
  };
  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="content">
            <Route exact path="/" component={Home} />
            <Route path="/Form" component={Form} />
            <Route path="/RedeemJpMiles" component={RedeemJpMiles} />
            <Route path="/OffersDeals" component={OffersDeals} />
            <Route path="/AboutUs" component={AboutUs} />
            <Route path="/Enrol" component={Enrol} />
          </div>
        </div>
      </div>
    );
  }
}

export default Content;
