import React, { Component } from "react";
import logo from "./images/logo.png";
import { NavLink } from "react-router-dom";

class Header extends Component {
  render() {
    return (
      <div className="header">
        <div className="container">
          <div className="row">
            <SiteLogo />
            <Navigation />
          </div>
        </div>
      </div>
    );
  }
}

class SiteLogo extends Component {
  render() {
    return (
      <div className="col-lg-3">
        <div className="logo">
          <a>
            <img src={logo} alt="My logo" />
          </a>
        </div>
      </div>
    );
  }
}

class Navigation extends Component {
  render() {
    return (
      <div className="col-lg-9">
        <nav className="navbar">
          <ul className="nav">
            <li className="nav-item">
              <NavLink exact to="/">
                Home
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink to={"/Form"}>Form</NavLink>
            </li>
            <li className="nav-item">
              <NavLink to={"/RedeemJpMiles"}>Redeem JP Miles</NavLink>
            </li>
            <li className="nav-item">
              <NavLink to={"/OffersDeals"}>Offers & Deals</NavLink>
            </li>
            <li className="nav-item">
              <NavLink to={"/AboutUs"}>About Us</NavLink>
            </li>
            <li className="nav-item">
              <NavLink to={"/Enrol"}>Enrol</NavLink>
            </li>
          </ul>
        </nav>
      </div>
    );
  }
}

export default Header;
