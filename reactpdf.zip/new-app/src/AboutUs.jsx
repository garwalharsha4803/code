import React, { Component } from "react";

class AboutUs extends Component {
  state = {
    c: 0,
    tags: []
  };

  handleRequest() {
	this.setState({ c: this.state.c + 1 });
	
  }
  render() {
    return (
      <div>
        <p>{this.state.c}</p>
        <button onClick={this.handleRequest.bind(this)}>Click Me </button>
        Welcome to About Us page !!!!
      </div>
    );
  }
}

export default AboutUs;
