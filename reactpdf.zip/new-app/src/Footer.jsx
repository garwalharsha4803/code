import React, { Component } from "react";
import { NavLink } from "react-router-dom";

class Footer extends Component {
  state = {};
  render() {
    return (
      <div className="footer">
        <div className="container">
          <div className="row">
            <div className="col-lg-9">
              <nav className="footer_navbar">
                <ul className="footer_nav">
                  <li className="footer-nav-item">
                    <NavLink exact to="/">
                      Home
                    </NavLink>
                  </li>
                  <li className="footer-nav-item">
                    <NavLink to={"/EarnJpMiles"}>Earn JP Miles</NavLink>
                  </li>
                  <li className="footer-nav-item">
                    <NavLink to={"/RedeemJpMiles"}>Redeem JP Miles</NavLink>
                  </li>
                  <li className="footer-nav-item">
                    <NavLink to={"/OffersDeals"}>Offers & Deals</NavLink>
                  </li>
                  <li className="footer-nav-item">
                    <NavLink to={"/AboutUs"}>About Us</NavLink>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Footer;
