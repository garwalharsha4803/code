import React, { Component } from "react";
import Form from "./Form";
import Content from "./Content";

class RightSidebar extends Component {
  render() {
    return (
      <div>
        <Content />
      </div>
    );
  }
}

export default RightSidebar;
