import React, { Component } from "react";

class OffersDeals extends Component {
  render() {
    return (
      <div>
        Welcome to Offers & Deals page !!!!
        <UserForm />
      </div>
    );
  }
}

class UserForm extends Component {
  constructor() {
    super();
    this.state = { fname: "", lname: "", email: "" };
  }
  render() {
    const { fname, lname, email } = this.state;
    return (
      <form>
        <input
          type="text"
          value={fname}
          name="fname"
          onChange={this.onChange}
        />
        <input
          type="text"
          value={lname}
          name="fname"
          onChange={this.onChange}
        />
        <input
          type="text"
          value={email}
          name="email"
          onChange={this.onChange}
        />
      </form>
    );
  }
  onChange = e => {
    this.setState({ [e.target.name]: e.target.value });
  };
}

export default OffersDeals;
