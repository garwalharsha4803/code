import React, { Component } from "react";
import logo from "./logo.svg";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";

class App extends Component {
  render() {
    var i = 1;

    var mystyle = {
      fontSize: 100,
      color: "#FF0000"
    };
    return (
      <div>
        <h2>Header</h2>
        <h3>Content</h3>
        <p data-attributes="somevalue">This is some value</p>
        <h1>{4 + 4}</h1>
        <h4>{i == 2 ? "True" : "False"}</h4>
        <h1 style={mystyle}>Header</h1>
        <Header />
        <Content />
      </div>
    );
  }
}

class Header extends React.Component {
  render() {
    return (
      <div>
        <h1>Header</h1>
      </div>
    );
  }
}
class Content extends React.Component {
  render() {
    return (
      <div>
        <h2>Content</h2>
        <p>The content text!!!</p>
      </div>
    );
  }
}

export default App;
