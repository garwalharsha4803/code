import React, { Component } from "react";

class Form extends Component {
  state = {
    firstname: "",
    lastname: "",
    username: "",
    email: "",
    password: ""
  };

  change = e => {
    this.setState({
      [e.target.name]: e.target.value
    });
  };

  onSubmit = e => {
    e.preventDefault();
    this.props.onSubmit(this.state);
    this.setState({
      firstname: "",
      lastname: "",
      username: "",
      email: "",
      password: ""
    });
  };
  render() {
    return (
      <div>
        <form>
          <div className="form_content">
            <div className="form_elements">
              <label>Firstname</label>
              <input
                name="firstname"
                value={this.state.firstname}
                onChange={e => this.change(e)}
              />
            </div>
            <div className="form_elements">
              <label>Lastname</label>
              <input
                name="lastname"
                value={this.state.lastname}
                onChange={e => this.change(e)}
              />
            </div>
            <div className="form_elements">
              <label>username</label>
              <input
                name="username"
                value={this.state.username}
                onChange={e => this.change(e)}
              />
            </div>

            <div className="form_elements">
              <label>email</label>
              <input
                name="email"
                value={this.state.email}
                onChange={e => this.change(e)}
              />
            </div>
            <div className="form_elements">
              <label>password</label>
              <input
                name="password"
                type="password"
                value={this.state.password}
                onChange={e => this.change(e)}
              />
            </div>

            <div className="form_btn">
              <button onClick={e => this.onSubmit(e)}>Submit</button>
            </div>
          </div>
        </form>
      </div>
    );
  }
}

export default Form;
