import React, { Component } from "react";

class Todo extends Component {
  state = {
    username: "",
    array: []
  };

  handlesubmit = event => {
    event.preventDefault();
    const arr = this.state.array;
    const username = this.state.username;
    const cc = arr.concat(username);

    this.setState({
      array: cc
    });
    this.state.username = "";
  };

  handleChange = event => {
    const target = event.target;
    const name = target.name;
    const value = target.value;

    this.setState({ [name]: value });
  };

  handleDelete = counter => {
    console.log(counter);
    const counterId = this.state.array.splice(counter, 1);
    this.setState(counterId);
  };

  render() {
    return (
      <div className="container-fuid">
        <form action="#" onSubmit={this.handlesubmit}>
          <input
            type="text"
            onChange={this.handleChange}
            value={this.state.username}
            name="username"
          />
          <button type="submit">Add</button>
        </form>
        <div className="display">
          {this.state.array.map((todo, index) => (
            <li key={index} id={index}>
              {todo}
              <button
                className="delete"
                onClick={() => this.handleDelete(index)}
              >
                Delete
              </button>
            </li>
          ))}
        </div>
      </div>
    );
  }
}

export default Todo;
