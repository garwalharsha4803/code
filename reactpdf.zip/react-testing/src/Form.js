import React, { Component } from "react";

class Form extends Component {
  state = {
    username: "",
    text: "Harsha",
    mode: "view"
  };

  handleAdd = () => {
    this.setState({
      text: this.state.username,
      mode: "view"
    });
  };

  handleChange = e => {
    this.setState({
      username: e.target.value
    });
  };

  handleEdit = () => {
    this.setState({
      mode: "edit"
    });
  };

  render() {
    if (this.state.mode === "view") {
      return (
        <div>
          <p>Text : {this.state.text}</p>
          <button type="button" onClick={this.handleEdit}>
            Edit
          </button>
        </div>
      );
    }
    return (
      <div>
        <p>Text : {this.state.text}</p>
        <input
          type="text"
          onChange={this.handleChange}
          value={this.state.username}
        />
        <button type="button" onClick={this.handleAdd}>
          Add
        </button>
      </div>
    );
  }
}

export default Form;
