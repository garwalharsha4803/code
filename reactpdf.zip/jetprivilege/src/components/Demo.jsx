import React, { Component } from "react";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      header: "header",
      footer: "Footer"
    };
  }

  render() {
    return (
      <div>
        {this.props.propheader}
        {this.props.propfooter}
      </div>
    );
  }
}

class App2 extends Component {
  state = {};
  render() {
    return <div>{56}</div>;
  }
}

export default App;
