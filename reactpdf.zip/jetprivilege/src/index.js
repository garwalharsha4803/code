import React from "react";
import ReactDom from "react-dom";
import "bootstrap/dist/css/bootstrap.css";
import App from "./components/Demo";

//ReactDom.render(<Counter name="Harsha111" />, document.getElementById("root"));

ReactDom.render(
  <App
    propheader="This is header content"
    propfooter="This is footer content"
  />,
  document.getElementById("root")
);
