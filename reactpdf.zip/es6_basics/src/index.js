// var is accessible inside the function block
// let is accessible inside the block only
// const - value cannot be override eg: const i = 2, i = 4;
// Objects are collections of key-value pair

function sayHello() {
  for (let i = 0; i < 5; i++) {
    console.log(i);
  }
}
sayHello();

const person = {
  name: "Harsha",
  walk() {
    console.log(this);
  },
  talk() {}
};

// when we know which property to access we use dot operator
person.walk();
person.name = "";

//When we don't know property we use below method
const targetMember = "name";
person[targetMember] = "John";

// Using this keyword which refers to the current object

const person1 = {
  name: "John",
  bolk() {
    console.log(this);
  }
};
person1.bolk();

const bolk = person1.bolk;
bolk();

// Arrow functions

const square = function(number) {
  return number * number;
};

const square1 = number => number * number;
console.log(square1(5));

// 2nd example of arrow funct

const jobs = [
  { id: 1, isActive: true },
  { id: 2, isActive: true },
  { id: 3, isActive: false }
];

const activeJobs = jobs.filter(function(job) {
  return job.isActive;
});
const activeJobs1 = jobs.filter(job => job.isActive);

// Arrow function never rebind this keyword

const mada = {
  dam() {
    var self = this;
    setTimeout(() => console.log("self", self));
  }
};
mada.dam();

//Array map

const colors = ["red", "green", "blue"];

const items = colors.map(color => `<li>${color}</li>`);
console.log(items);

// Here ` symbol is template literal
//$(color) is rendering dynamically

// Now Object Destructuring

const address = {
  street: "",
  city: "",
  country: ""
};

const street1 = address.street;
const city1 = address.city;
const country1 = address.country;

// Object destructuring is minimum code like this below

const { street, city, country } = address;

// If we want different const name, use alias name below

const { street: st } = address;

// Spread Operators

const first = [1, 2, 3];
const second = [5, 6, 7];

const combined = first.concat(second);

const combined1 = [...first, "a", ...second];
console.log(combined);
console.log(combined1);
