# React Form Validation Demo

This is a simple demo app for showing how to do basic form validation in React.

[See the app running on Heroku](https://reactform.herokuapp.com).

It includes a sign up form with email and password input fields and a sign up button.

For more on how to generalise the validations, have a look at [The Complete React on Rails Course](learnetto.com/users/hrishio/courses/the-complete-react-on-rails-5-course).