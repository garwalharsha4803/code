// flow-typed signature: b0a8c8851219a1c2a933509d842e0bc8
// flow-typed version: 4a2d036a51/normalize.css_v7.x.x/flow_>=v0.34.x

// normalize.css may be imported for side-effects,
// e.g. to force webpack to bundle it alongside CSS modules

declare module "normalize.css" {
  declare export default empty
}
