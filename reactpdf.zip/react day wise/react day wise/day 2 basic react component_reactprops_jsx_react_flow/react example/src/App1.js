import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';



class App1 extends Component {
  render() {
    return (
      <div className="App1">
        hello Accenture
      </div>
    );
  }
}

export default App1;
