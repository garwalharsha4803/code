import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
class Employee extends Component {
    handleRequest = () => {
        this.setState({ c: this.state.c + 1 });
      };

    state = {
         c:0,
     }
     render() { 
        return ( 
            <div>
                <span className={this.getBadgeClasses()}>{this.formatCount()}</span>
 
                <button onClick={() => this.handleRequest() }>click me</button>
               
            </div>
         );
    }
    getBadgeClasses() {
        let classes = "badge m-2 badge-";
        classes += this.state.c === 0 ? "warning" : "primary";
        return classes;
      };
    
      formatCount() {
        const { c } = this.state;   //this.state.c
        return c === 0 ? "Zero" : c;
      };

}
 
export default Employee;