import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Employee from './component/employee';

const dd=<h1>gfjh</h1>
console.log(dd);

ReactDOM.render(<Employee />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
//serviceWorker.unregister();
