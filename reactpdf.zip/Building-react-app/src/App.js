import React from "react";
import logo from "./logo.svg";
import "./App.css";
import CoursePage from "./components/CoursePage";

function App() {
  return (
    <div className="App">
      <CoursePage />
    </div>
  );
}

export default App;
