import { combineReducers } from Redux;
import courses from "./CourseReducer";

const rootReducer = combineReducers({
    courses:courses
});

export default rootReducer;