export default function createrReducer(state = [], action) {
  switch (action.type) {
    case "CREATE_COURSE":
      return [...state, { ...action.course }];
    default:
      return state;
  }
}

//Each reducer handles a specific slice of state
// Slice management into numbers which are called reducers  (somewhat)
