export function createCourse(course) {
  return {
    type: "CREATE_COURSE",
    course
  };
}

// course is a payload and type is must in action creators
