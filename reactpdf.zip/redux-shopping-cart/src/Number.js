import React, { Component } from 'react';

class Number extends Component {
    state = {}
    render() {
        return (
            <div>
                Hii
            </div>
        );
    }
}

export default Number;