import React from "react";
import logo from "./logo.svg";
import "./App.css";
import Todo from "./Todo";
import Form from "./Form";
import Counter from "./Counter";

function App() {
  return (
    <div className="App">
      {/* <Todo />
      <Form /> */}
      <Counter />
    </div>
  );
}

export default App;
