import React, { Component, useState, useEffect } from "react";

function ClickCounter(props) {
  //   const [Counter, setCount] = useState(1);
  //   const handleClick = () => setCount(Counter + 1);

  return (
    <div>
      <h3>{props.Counter}</h3>
      <button onClick={props.onClikcFunction}>+{props.increment}</button>
    </div>
  );
}

function Button() {
  const [Counter, setCount] = useState(1);
  const handleClick = incrementValue => setCount(Counter + incrementValue);

  return (
    <div>
      <ClickCounter onClikcFunction={() => handleClick()} increment={1} />
      <ClickCounter onClikcFunction={() => handleClick()} increment={10} />
      <ClickCounter onClikcFunction={() => handleClick()} increment={15} />
      <ClickCounter onClikcFunction={() => handleClick()} increment={100} />
    </div>
  );
}

export default Button;
