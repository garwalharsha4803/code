import React, { Component } from "react";
import { Route, NavLink } from "react-router-dom";
import Popup from "./Popup";

class Navbar extends Component {
  state = {
    showpopup: false
  };

  popuphandle = () => {
    this.setState({ showpopup: !this.state.showpopup });
  };

  render() {
    return (
      <div className="router">
        <nav className="nav">
          <ul className="nav">
            <li className="nav-item">
              <NavLink exact to="/">
                Home
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink to={"/Form"}>Form</NavLink>
            </li>
            <li className="nav-item">
              <NavLink to={"/TodoList"}>Todo </NavLink>
            </li>
            <li className="nav-item">
              <NavLink to={"/TodoEx"}>Todo Ex</NavLink>
            </li>
            <li className="nav-item">
              <NavLink to={"/PureComponents"}>Pure</NavLink>
            </li>
            <li className="nav-item">
              <NavLink to={"/Booking"}>Booking</NavLink>
            </li>
            <li className="nav-item popup_box">
              <NavLink to={"/Enrol"}>Enrol</NavLink>
            </li>
            <li className="nav-item popup_box">
              <input
                type="button"
                onClick={this.popuphandle}
                value="ShowPopup"
              />
              {this.state.showpopup ? (
                <Popup closeicon={this.popuphandle} />
              ) : (
                ""
              )}
            </li>
          </ul>
        </nav>
      </div>
    );
  }
}

export default Navbar;
