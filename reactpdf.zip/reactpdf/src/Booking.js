import React, { Component } from "react";
import LazyLoad from "react-lazyload";
import { Scrollbars } from "react-custom-scrollbars";
import "react-tabs/style/react-tabs.css";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";

class Booking extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isupcoming: true,
      iscompleted: false,
      iscancelled: false,
      data: "",
      loading: true
    };
  }

  handleUpdate = () => {
    this.setState({
      isupcoming: true,
      iscompleted: false,
      iscancelled: false
    });
  };

  handleCompleted = () => {
    this.setState({
      isupcoming: false,
      iscompleted: true,
      iscancelled: false
    });
  };

  handlecancelled = () => {
    this.setState({
      isupcoming: false,
      iscompleted: false,
      iscancelled: true
    });
  };

  apiClick = () => {
    fetch("http://www.mocky.io/v2/5d442df52f00008029179539")
      .then(response => response.json())
      .then(data => {
        this.setState({ data, loading: false });
      })
      .catch(error => {
        console.log(error, "<= API Error");
      });
  };

  componentDidMount() {
    this.apiClick();
  }

  render() {
    return (
      <div className="container_booking">
        <div className="left">Left</div>
        <div className="right">
          <TabList>
            <Tab>Title 1</Tab>
            <Tab>Title 2</Tab>
          </TabList>

          <TabPanel>
            <h2>Any content 1</h2>
          </TabPanel>
          <TabPanel>
            <h2>Any content 2</h2>
          </TabPanel>
          <div className="tabbox">
            <button
              className={this.state.isupcoming ? "active" : ""}
              onClick={this.handleUpdate}
            >
              Upcoming
            </button>
            <button
              className={this.state.iscompleted ? "active" : ""}
              onClick={this.handleCompleted}
            >
              Completed
            </button>
            <button
              className={this.state.iscancelled ? "active" : ""}
              onClick={this.handlecancelled}
            >
              Cancelled
            </button>

            <div className="showbox">
              <Upcoming
                isupcoming={this.state.isupcoming ? this.apiClick : "Loader"}
              />
              <Completed
                iscompleted={this.state.iscompleted ? "Completed" : ""}
                isupcoming="false"
              />
              <Cancelled
                iscancelled={this.state.iscancelled ? "Cancelled" : ""}
              />
            </div>
            <Scrollbars style={{ width: 790, height: 700 }}>
              <div className="apibutton">
                {this.state.data
                  ? this.state.data.map((data, index) => (
                      <React.Fragment>
                        {
                          <ShowApiData
                            jpnumber={data.jpnumber}
                            hotelname={data.hotelname}
                            bookingid={data.reservation_id}
                            status={data.Status}
                            checkin={data.CheckInDate}
                            checkout={data.checkout}
                          />
                        }
                      </React.Fragment>
                    ))
                  : this.state.loading}
              </div>
            </Scrollbars>
          </div>
        </div>
      </div>
    );
  }
}

class ShowApiData extends Component {
  state = {};
  render() {
    return (
      <LazyLoad height={200} offset={100} once>
        <div className="show_api_data">
          <div className="bkc_box_left">
            <span className="booking_confirmed"> {this.props.status}</span>
            <span className="hotel_name">{this.props.hotelname}</span>
            <span className="book_id">
              Booking Id : <span> {this.props.bookingid}</span>
            </span>
            <button className="manage_button" type="button">
              Manage Booking
            </button>
          </div>
          <div className="bkc_box_right">
            <div className="bkc_box_up">
              <div className="bkc_checkin">
                <label>check in</label>
                <p>
                  {this.props.checkin}, Sat, <span>date</span>
                </p>
                <label>Guest</label>
                <span>2 Adult 1 children</span>
              </div>
              <div className="bkc_checkout">
                <label>check Out</label>
                <p>
                  {this.props.checkout}
                  <span>date</span>
                </p>
                <label>Room</label>
                <span>1x Classic Suit</span>
              </div>
            </div>
            <div className="bkc_box_down">
              <span className="miles_credit">2500 JPMiles will credited</span>
              <span className="cancellation">
                Zero cancellation till 25 Jun 2019
              </span>
            </div>
          </div>
        </div>
      </LazyLoad>
    );
  }
}

class Upcoming extends Component {
  state = {};
  render() {
    return <div>{this.props.isupcoming}</div>;
  }
}

class Completed extends Component {
  state = {};
  render() {
    return <div>{this.props.iscompleted}</div>;
  }
}

class Cancelled extends Component {
  state = {};
  render() {
    return <div>{this.props.iscancelled}</div>;
  }
}

export default Booking;
