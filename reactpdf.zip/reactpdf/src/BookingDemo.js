import React, { Component } from 'react';

class Booking extends Component {
    state = {
        tabData: [
            {
                name: 'Tab1', isActive: true
            },
            {
                name: 'Tab2', isActive: false
            },
            {
                name: 'Tab2', isActive: false
            }
        ]
    }

    getInitialState = () => {
        const activeTab = this.state.tabData[0]
        console.log(activeTab)
    }

    handleClick = (tab) => {
        this.setState({
            activeTab: tab
        })
    }

    render() {
        return (
            <div className="container_booking">
                <div className="left">
                    Left
                </div>
                <div className="right">
                    <div className="tabs">



                        <Tabs activeTab={this.state.activeTab} changeTab={this.handleClick} tabdata={this.state.tabData.map((tab) => <Tab data={tab} isActive={this.state.activeTab === tab} handleClick={() => this.handleClick(tab)} />)} />
                        <Content activeTab={this.state.tabData.name} />
                    </div>

                </div>
            </div>
        );
    }
}

class Tabs extends Component {
    state = {}
    render() {
        return (
            <div>
                <ul className="nav nav-tabs">
                    <li>{this.props.activeTab}</li>
                </ul>
            </div>
        );
    }
}

class Tab extends Component {
    state = {}
    render() {
        return (
            <div>
                <li className={this.props.isActive ? "active" : ""} onClick={this.props.handleClick}>
                    <a href="#">{this.props.data.name}</a>
                </li>
            </div>
        );
    }
}


class Content extends Component {
    state = {}
    render() {
        return (
            <div>
                {this.props.activeTab === 'Tab1' ? "Tab11" : ""}
                {this.props.activeTab === 'Tab2' ? "Tab12" : ""}
                {this.props.activeTab === 'Tab3' ? "Tab13" : ""}
            </div>
        );
    }
}


export default Booking;