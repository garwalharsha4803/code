import React, { Component } from "react";

class Status extends Component {
  state = {
    count: 0,
    status: 0,
    array: []
  };

  handleClick = () => {
    console.log("hyy");
    const displ = this.setState({ count: this.state.count + 1 });
    const display = this.state.array.concat(displ);
    this.setState({ array: display });
  };

  handleStatus = () => {
    setInterval(() => {
      {
        this.setState({
          status: this.state.status + 1
        });
      }
    }, 3000);
  };

  render() {
    return (
      <div>
        <div className="container">
          <button className="plus" onClick={this.handleClick}>
            +
          </button>
          <Child />

          {this.state.array.map(() => (
            <div className="box">
              <span>
                Message :{" "}
                {Math.random()
                  .toString(36)
                  .substr(2, 3)}
              </span>
              <br />
              <span>Status : {this.state.status}</span>
            </div>
          ))}
        </div>
      </div>
    );
  }
}

class Child extends Component {
  state = {
    value: [],
    textValue: ""
  };

  handlechange = e => {
    this.setState({
      textValue: e.target.value
    });
  };

  handlebuttonclick = () => {
    this.state.value.push(this.state.textValue);
    this.setState(this.state);
    this.state.textValue = "";
  };

  handledelete = v => {
    for (var i = 0; i < this.state.value.length; i++) {
      if (this.state.value[i] == v) {
        delete this.state.value[i];
      }
    }
    this.setState({ value: this.state.value });
  };

  render() {
    const { value } = this.state;
    return (
      <div>
        <input
          type="text"
          onChange={this.handlechange}
          placeholder="Please enter input"
        />
        <button type="submit" onClick={this.handlebuttonclick}>
          Add Item
        </button>

        {value.map(v => {
          return (
            <div>
              <button type="submit" onClick={() => this.handledelete(v)}>
                Delete
              </button>
              {v}
            </div>
          );
        })}
      </div>
    );
  }
}

export default Status;
