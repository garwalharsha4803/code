import React from 'react';
import logo from './logo.svg';
import './App.css';
import ContactFormDemo from './FormDemo';

class CommentBox extends React.Component {
    constructor() {
        super();
        this.state = {
            show: false,
            display: false
        }
    }

    // _getComments() {
    //   const commentList = [
    //     { id: 1, author: "Scott", body: "desc 1" },
    //     { id: 2, author: "Michael", body: "desc 2" },
    //     { id: 3, author: "Pam", body: "desc 3" }
    //   ];

    //   return commentList.map((comment) => {
    //     return <Comment author={comment.author} body={comment.body} key={comment.id} />
    //   })
    // }

    _getCommentTitle(count) {
        if (count == 0) {
            return "No Comment";
        }
        else if (count == 1) {
            return "Comment";
        }
        else {
            return "comments"
        }
    }

    onClickHandler = () => {
        this.setState({ show: !this.state.show })
    }

    render() {
        // const comments = this._getComments();

        return (
            <div className="comment-box">
                <CommentForm />
                <h3>Comments</h3>
                {/* <h4 className="comment-count">{comments.length} {this._getCommentTitle(comments.length)} </h4> */}
                {/* <h4 className="comment-count"> {comments.length == 1 ? "comment" : "comments"} </h4> */}

                {/* {this.state.show ? <div className="comment-list">{comments}</div> : ""} */}
                <button onClick={this.onClickHandler}>{this.state.show ? "Hide Comments" : "Show Comments"}</button>


            </div>
        );
    }
}

class CommentForm extends React.Component {
    constructor() {
        super();
        this.state = {
            inpuValue: '',
            area: '',
            array: [],
            desc: []
        }
    }

    handleInput = (event) => {
        this.setState({ [event.target.name]: event.target.value })
    }

    submitHandler = (event) => {
        event.preventDefault();
        this.setState({
            display: true
        })
        // let data = this.state.array.concat(this.state.inpuValue)
        // let disp = data.map((dd) => dd)


    }


    render() {
        return (
            <form className="comment-form" onSubmit={this.submitHandler}>
                <br />
                <hr></hr>
                <label>Join the discussion</label><br />
                <div className="comment-field">

                    <input type="text" placeholder="Enter input" onChange={this.handleInput} value={this.state.inpuValue} name="inpuValue"></input><br /><br />

                    <textarea placeholder="Enter comment" name="area" onChange={this.handleInput} value={this.state.area}></textarea>

                </div><br />
                <div className="comment-action">
                    <button type="submit">Post Submit</button>
                </div>

                <Comment author={this.state.display ? this.state.array.concat(this.state.inpuValue) : ""} />
            </form>

        );
    }
}

class Comment extends React.Component {

    render() {
        return (
            <div className="comment">
                <p className="comment-header">{this.props.author}</p>
                {/* <p className="comment-body">{this.props.body}</p> */}
            </div>
        );
    }
}

export default CommentBox;

