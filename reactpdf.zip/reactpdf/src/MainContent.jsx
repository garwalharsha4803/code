import React, { Component } from "react";
import { Route } from "react-router-dom";
import Enrol from "./Enrol";
import Todo from "./TodoList";
import Form from "./Form";
import TodoEx from "./TodoEx";
import Pure from "./PureComponents";
import Booking from "./Booking";
import Status from "./Home";

class MainContent extends Component {
  state = {};
  render() {
    return (
      <div>
        <Route exact path="/" component={Status} />
        <Route path="/Form" component={Form} />
        <Route path="/Enrol" component={Enrol} />
        <Route path="/TodoList" component={Todo} />
        <Route path="/TodoEx" component={TodoEx} />
        <Route path="/PureComponents" component={Pure} />
        <Route path="/Booking" component={Booking} />
      </div>
    );
  }
}

export default MainContent;
