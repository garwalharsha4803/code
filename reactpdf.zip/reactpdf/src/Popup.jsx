import React, { Component } from "react";

class Popup extends Component {
  state = {
    show: false
  };

  handlesubmit = event => {
    event.preventDefault();
    let fname = document.getElementById("fname").value;
    let password = document.getElementById("password").value;
    this.setState({ fname, password, show: true });
  };

  render() {
    return (
      <div>
        <div className="popup">
          <div className="popup_inner">
            <h3>Login</h3>
            <button className="close_popup" onClick={this.props.closeicon}>
              X
            </button>

            <form onSubmit={this.handlesubmit}>
              <input type="text" id="fname" autoComplete="off" /> <br />
              <input type="password" id="password" autoComplete="off" />
              <br />
              <br />
              <button type="submit">Submit</button>
            </form>

            {this.state.show ? (
              <ShowData
                firstname={this.state.fname}
                password={this.state.password}
              />
            ) : (
              ""
            )}
          </div>
        </div>
      </div>
    );
  }
}

class ShowData extends Component {
  render() {
    return (
      <div className="show_data">
        Firstname : {this.props.firstname}
        <br />
        Password: {this.props.password}
      </div>
    );
  }
}
export default Popup;
