import React, { Component } from "react";

// class Form extends Component {
//   state = {
//     show: false,
//     valid: true
//   };

//   validateEmail(email) {
//     const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
//     return re.test(email);
//   }

//   handleSubmit = event => {
//     event.preventDefault();
//     const email = document.getElementById("email").value;
//     const emailValid = this.validateEmail(email);
//     this.setState({ email, show: true, valid: emailValid });
//   };

//   render() {
//     const { email, valid } = this.state;

//     return (
//       <div>
//         <form onSubmit={this.handleSubmit}>
//           <label>Email</label>
//           <div className="fieldContainerClass">
//             <input
//               type="email"
//               name="email"
//               id="email"
//               placeholder="Please enter email"
//             />
//             <br />
//             <br />
//           </div>

//           <button type="submit">Submit</button>
//         </form>
//         {this.state.valid ? this.state.email : ""}
//       </div>
//     );
//   }
// }
class Form extends Component {
  constructor(props) {
    super(props);
    this.state = {
      value: ["a", "b", "c", "d", "e"],
      textvalue: ""
    };
  }

  handleChange = e => {
    this.setState({
      textvalue: e.target.value
    });
  };
  handleAddTodoItem = () => {
    this.state.value.push(this.state.textvalue);
    this.setState(this.state);
    console.log(this.state.value);
  };
  handledelTodoItem = v => {
    for (var i = 0; i < this.state.value.length; i++) {
      if (this.state.value[i] == v) {
        delete this.state.value[i];
      }
    }
    this.setState({
      value: this.state.value
    });
    console.log(this.state.value);
  };
  render() {
    let { value } = this.state;
    return (
      <div>
        <input
          type="text"
          placeholder="fgbg"
          className="text"
          onChange={this.handleChange}
        />
        <button className="addbutton" onClick={this.handleAddTodoItem}>
          Add Todo Item
        </button>
        {value.map(v => {
          return (
            <div>
              <h1 className="font">
                <button
                  className="allbutton"
                  onClick={this.handledelTodoItem.bind(this, v)}
                >
                  DelTodoItem
                </button>
                {v}
              </h1>
            </div>
          );
        })}
      </div>
    );
  }
}

export default Form;
