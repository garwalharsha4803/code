import React, { Component } from 'react';

class CommentForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            show: false,
            fname: ""
        }
    }

    changeHandler = (event) => {
        this.setState({ [event.target.name]: event.target.value })
    }

    handleSubmit = (e) => {
        e.preventDefault();
        this.setState({ show: true })
    }

    render() {

        return (<div>
            <br /><br />
            <form onSubmit={this.handleSubmit}>
                <input type="text" placeholder="Enter Firstname" name="fname" value={this.state.fname} onChange={this.changeHandler} autoComplete="off"></input>
                <br /><br />
                <button type="submit">Submit</button>
                {this.state.show ? <Comment firstname={this.state.fname} /> : ""}
            </form>
        </div>
        );
    }
}

class Comment extends React.Component {

    render() {
        return (
            <div>
                <p>Firstname: {this.props.firstname}</p>
            </div>
        );
    }
}

export default CommentForm;

