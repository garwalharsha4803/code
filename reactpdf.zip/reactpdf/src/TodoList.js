import React, { Component } from "react";

class Todo extends Component {
  constructor() {
    super();
    this.state = {
      name: "",
      display: []
    };
  }

  handleSubmit = event => {
    event.preventDefault();
    let name = document.getElementById("name").value;
    let disp = this.state.display.concat(name);
    this.setState({ display: disp });
  };

  render() {
    return (
      <React.Fragment>
        <form onSubmit={this.handleSubmit}>
          <input
            type="text"
            placeholder="Enter input"
            id="name"
            autoComplete="off"
          ></input>
          <button type="submit">Add</button>
          <br></br>
          <br />
        </form>

        <TodoDispaly
          list={this.state.display.map(da => (
            <li>{da}</li>
          ))}
        />
      </React.Fragment>
    );
  }
}

class TodoDispaly extends Component {
  render() {
    return <div>{this.props.list}</div>;
  }
}

export default Todo;
