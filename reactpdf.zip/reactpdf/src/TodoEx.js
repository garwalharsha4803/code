import React, { Component } from 'react';

class TodoEx extends Component {
    constructor(props) {
        super(props);
        this.state = {
            name: "Simple React Todo List",
            tasks: ['just', 'simple', 'thing'],
            display: []

        }
    }

    handleSubmit = (event) => {
        event.preventDefault();
        let disp = document.getElementById("name").value;
        let display = this.state.display.concat(disp);
        this.setState({ display: display })
    }

    handleDelete = (counterId) => {
        console.log("Event Handling", counterId);
        const counter = this.state.display.splice(counterId, 1)
        this.setState({ counter })

    }

    handleEdit = () => {

    }

    render() {

        return (
            <div className="container">
                <h1>{this.state.name}</h1>
                <div>
                    {this.state.tasks.map(task => <li> {task}</li>)}
                </div>
                <div>
                    <form name="sendTask" onSubmit={this.handleSubmit} >
                        <input name="name" value={this.state.task} id="name" />
                        <button type="submit" name="addTask">Add</button>
                    </form>
                </div>
                <div className="dispalybox">
                    {this.state.display.map((da, index) => <li key={index} id={index}>{da}<button onClick={() => this.handleDelete(index)}>X</button></li>)}
                </div>
            </div>
        );
    }
}




export default TodoEx;