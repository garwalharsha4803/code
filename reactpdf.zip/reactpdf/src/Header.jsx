import React, { Component } from 'react';
import './jetprivilege.css';


import Navbar from "./Navigation"


class Header extends Component {


    render() {
        return (
            <div className="container">
                <div className="header">
                    <div className="jp_logo">
                        <img src="./jp-logo.svg" alt="logo" /> <br />
                    </div>
                    <div className="navbar">
                        <Navbar />
                    </div>



                </div>
            </div>
        );
    }
}







export default Header;