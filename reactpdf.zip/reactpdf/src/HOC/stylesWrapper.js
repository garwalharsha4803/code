import React, { Component } from "react";

import commontyles from "./../styles/commonstyles";

export default WrappedComponent => {};
