import React, { Component } from "react";
import stylesWrapper from "./../HOC/stylesWrapper";

const ButtonOne = props => {
  let _styles = { ...styles.default };

  if (props.disable) {
    _styles = { ..._styles, ...styles.disable };
  }

  return <button style={_styles}>I am a Button</button>;
};

export default stylesWrapper(ButtonOne);
