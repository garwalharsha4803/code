import React, { Component } from 'react';
import Todo from './TodoList'

class Enrol extends Component {

    constructor() {
        super();
        this.state = {
            array: [],
            isSubmitted: false
        }
    }

    handleSubmit = (event) => {
        event.preventDefault();
        const fname = document.getElementById("fname").value;
        const mname = document.getElementById("mname").value;
        const lname = document.getElementById("lname").value;
        const desc = document.getElementById("desc").value;
        const country = document.getElementById("country").value;
        const city = document.getElementById("city").value;
        this.setState({ fname, mname, lname, desc, country, city, isSubmitted: true })
    }

    render() {
        return (
            <div className="form_page">
                <form onSubmit={this.handleSubmit}>
                    <input type="text" placeholder="Enter firstname" id="fname" autoComplete="Off"></input><br /><br />

                    <input type="text" placeholder="Enter MiddleName" autoComplete="Off" id="mname"></input>
                    <br /><br />

                    <input type="text" placeholder="Enter LastName" id="lname" autoComplete="Off"></input>
                    <br /><br />

                    <textarea placeholder="Enter Description" id="desc" autoComplete="Off"></textarea>
                    <br /><br />

                    <select id="country">
                        <option>India</option>
                        <option>Afganistan</option>
                        <option>Dubai</option>
                    </select><br /><br />

                    <select id="city">
                        <option>Mumbai</option>
                        <option>Delhi</option>
                        <option>Indore</option>
                    </select><br /><br />

                    <button type="submit">Post</button>
                </form>
                {this.state.isSubmitted ? <Display firstname={this.state.fname} middlename={this.state.mname} lastname={this.state.lname} description={this.state.desc} country={this.state.country} city={this.state.city} /> : ""
                }            </div>
        );
    }
}

class Display extends Component {
    render() {
        return (

            <div>
                Firstname: {this.props.firstname}<br />
                Middlename: {this.props.middlename}<br />
                Lastname: {this.props.lastname}<br />
                Description: {this.props.description}<br />
                Country: {this.props.country}<br />
                City: {this.props.city}

                <Todo />
            </div>
        );
    }
}

export default Enrol;