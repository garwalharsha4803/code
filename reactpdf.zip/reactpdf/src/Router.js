import React, { Component } from 'react';
import { Link } from "react-router-dom";


class Router extends Component {

    render() {
        return (
            <Routers>
                <div>
                    <ul>
                        <li><Link to="/">Home</Link></li>
                        <li><Link to="/about">About</Link></li>
                    </ul>
                    <Route exact path="/" Component={Home}></Route>
                    <Route path="/about" Component={About}></Route>
                </div>
            </Routers>
        );
    }
}

const Home = () => (
    <div>Home Page</div>
)

const About = () => (
    <div>About Us Page</div>
)

export default Router;