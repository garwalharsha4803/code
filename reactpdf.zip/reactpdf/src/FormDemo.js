import React, { Component } from 'react';

//Form component
class ContactFormDemo extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            inputname: '',
            email: ''
        };
    }

    handleInputChange = (event) => {
        const target = event.target;
        const value = target.value;
        const name = target.name;

        this.setState({
            [name]: value
        });
        console.log('Change detected. State updated' + name + ' = ' + value);
    }

    handleSubmit = (event) => {
        alert('A form was submitted: ' + this.state.inputname + ' // ' + this.state.email);
        event.preventDefault();
    }

    render() {
        return (
            <div>
                <form onSubmit={this.handleSubmit} >
                    <div className="form-group">
                        <label for="nameImput">Name</label>
                        <input type="text" name="inputname" value={this.state.inputname} onChange={this.handleInputChange} className="form-control" id="nameImput" placeholder="Name" />
                    </div>
                    <div className="form-group">
                        <label for="emailImput">Name</label>
                        <input name="email" type="email" value={this.state.email} onChange={this.handleInputChange} className="form-control" id="emailImput" placeholder="email@domain.com" />
                    </div>
                    <input type="submit" value="Submit" className="btn btn-primary" />
                </form>
            </div>
        )
    }
}


export default ContactFormDemo;