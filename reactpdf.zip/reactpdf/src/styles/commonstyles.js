import React, { Component } from "react";

const styles = {
  default: {
    backgroundColor: "black",
    color: "white",
    padding: "10px"
  },
  disable: {
    backgroundColor: "green",
    color: "black"
  }
};

export default styles;
