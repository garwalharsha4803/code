import React, { Component } from "react";

const List = props => (
  <ul>
    {props.items.map((item, index) => (
      <ul>
        <li key={index}>{item}</li>
      </ul>
    ))}
  </ul>
);

export default List;
