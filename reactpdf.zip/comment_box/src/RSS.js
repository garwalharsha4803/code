import React, { Component } from "react";

class FetchDataFromRSSFeed extends Component {
  constructor() {
    super();
    this.state = {
      recentBlogPost: {
        name: "",
        url: "",
        date: ""
      }
    };
  }

  FetchDataFromRssFeed() {
    var request = new XMLHttpRequest();
    request.onreadystatechange = () => {
      if (request.readyState == 4 && request.status == 200) {
        var myObj = JSON.parse(request.responseText);
        for (var i = 0; i < 1; i++) {
          this.setState({
            recentBlogPost: {
              name: myObj.items[i].title,
              url: myObj.items[i].link,
              date: myObj.items[i].pubDate
            }
          });
        }
      }
    };
    request.open(
      "GET",
      "https://api.rss2json.com/v1/api.json?rss_url=https://aws.amazon.com/blogs/big-data/feed/",
      true
    );
    request.send();
  }

  componentDidMount() {
    {
      this.FetchDataFromRssFeed();
    }
  }

  render() {
    return (
      <div>
        Check out our blog: <br />
        {this.state.recentBlogPost.name}
        <br />
        {this.state.recentBlogPost.date}
        {/* <a target="_blank" href={this.state.recentBlogPost.url}>
          
        </a> */}
      </div>
    );
  }
}

export default FetchDataFromRSSFeed;
