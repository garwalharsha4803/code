import React, { Component } from "react";
import Parent from "./Increment_Decrement.jsx";
import Todolist from "./todolist.jsx";
import FetchDataFromRSSFeed from "./RSS";
import Panel from "./Display";
import Appp from "./demo";

import "./App.css";

class App extends Component {
  render() {
    return (
      <div>
        {/* <Parent /> */}
        {/* <Todolist />
        <FetchDataFromRSSFeed /> */}
        <Panel />
        {/* <Appp /> */}
      </div>
    );
  }
}

export default App;
