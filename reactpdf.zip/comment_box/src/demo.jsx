import React, { Component } from "react";
import Parent from "./Increment_Decrement.jsx";

import "./App.css";

class Appp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      clicks: 0,
      show: true
    };
  }

  IncrementItem = () => {
    this.setState({ clicks: this.state.clicks + 1 });
    console.log("Increment");
  };

  DecrementItem = () => {
    this.setState({ clicks: this.state.clicks - 1 });
    console.log("Decrement");
  };

  ToggleClick = () => {
    this.setState({ show: !this.state.show });
  };

  render() {
    return (
      <div>
        <butoon class="btn btn-default" onClick={this.IncrementItem}>
          Increment
        </butoon>
        <butoon class="btn btn-default" onClick={this.DecrementItem}>
          Decrement
        </butoon>
        <br />
        <br />
        <br />
        <button class="btn btn-primary" onClick={this.ToggleClick}>
          {this.state.show ? "Hide Number" : "Show Number"}
        </button>
        <br />
        <br />

        {this.state.show ? <h2>{this.state.clicks}</h2> : ""}

        {this.state.clicks}

        <Parent />
      </div>
    );
  }
}

export default Appp;
