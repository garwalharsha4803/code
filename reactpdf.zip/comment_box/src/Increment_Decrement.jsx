import React, { Component } from "react";

class Parent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      clicks: 0,
      show: true
    };
  }

  IncrementMethod = () => {
    this.setState({
      clicks: this.state.clicks + 1
    });
  };

  DecrementMethod = () => {
    this.setState({
      clicks: this.state.clicks - 1
    });
  };

  ToggleMethod = () => {
    this.setState({
      show: !this.state.show
    });
  };

  render() {
    return (
      <div>
        <button onClick={this.IncrementMethod} className="btn btn-primary">
          Increment
        </button>
        <button onClick={this.DecrementMethod} className="btn btn-primary">
          Decrement
        </button>
        <button onClick={this.ToggleMethod} className="btn btn-primary">
          {this.state.show ? "Hide Number" : "Show Number"}
        </button>
        <p>{this.state.show ? this.state.clicks : ""}</p>

        <br />
        <hr />
        <Child name="Harsha" />
      </div>
    );
  }
}

class Child extends Component {
  handleChange = e => {
    const name = e.target.value;
    this.props.onChange(name);
  };
  render() {
    return (
      <div>
        <p>Hey my Name is {this.props.name}</p>
        <select onChange={this.handleChange}>
          <option value="Garwal">name 1</option>
          <option value="Verma">name 2</option>
        </select>
      </div>
    );
  }
}

export default Parent;
