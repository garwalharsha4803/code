import React, { Component } from "react";
import List from "./DisplayList";

class Todolist extends Component {
  constructor(props) {
    super(props);
    this.state = {
      terms: "",
      items: []
    };
  }

  onChange = event => {
    this.setState({ terms: event.target.value });
  };

  onSubmit = event => {
    console.log("submit");
    this.setState({
      terms: "",
      items: [...this.state.items, this.state.terms]
    });
  };
  render() {
    return (
      <div className="todoListMain">
        <div className="header">
          <form onSubmit={this.onSubmit}>
            <input
              type="text"
              placeholder="Enter input"
              onChange={this.onChange}
            />
            <button type="button">Submit</button>
          </form>
          <List items={this.state.items} />
        </div>
      </div>
    );
  }
}

export default Todolist;
