import React, { Component } from "react";
import { Route } from "react-router-dom";
import Home from "./home";
import Blog from "./blog";
import Contact from "./contact";

class Content extends Component {
  render() {
    return (
      <div className="content">
        <Route exact path="/" component={Home} />
        <Route path="/blog" component={Blog} />
        <Route path="/contact" component={Contact} />
      </div>
    );
  }
}

export default Content;
