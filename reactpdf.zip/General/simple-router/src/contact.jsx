import React, { Component } from "react";

class Contact extends Component {
  render() {
    return (
      <div>
        <h2>Get In Touch</h2>
        <p>Phone: XXXXXXXXXX</p>
        <p>Email: XXXXX@XXXXX</p>
      </div>
    );
  }
}

export default Contact;
