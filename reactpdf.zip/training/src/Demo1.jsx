import React, { Component } from "react";

class Click1 extends Component {
  render() {
    function formatuser(user) {
      return user.firstname + " " + user.lastname;
    }
    const user = { firstname: "Harsha", lastname: "Verma" };

    return (
      <div>
        <h1>Hi</h1>
        {formatuser(user)}
      </div>
    );
  }
}

export default Click1;
